package com.greatLearning.lab;

import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String firstName, lastName, department = null;

		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter your first name");
		firstName = sc.next();

		System.out.println("Please enter your last name");
		lastName = sc.next();

		System.out.println("Please enter the department from following:\n1. Technical\n2. Admin\n3. Human Resource \n4. Legal");
		int dept = sc.nextInt();
		switch (dept) {
		case 1:
			department = "tech";
			break;

		case 2:
			department = "admin";
			break;

		case 3:
			department = "hr";
			break;

		case 4:
			department = "legal";
			break;

		}

		Employee emp = new Employee(firstName, lastName, department);
		CredentialServices empcred = new CredentialServices();
		empcred.generateEmailAddress(emp);
		empcred.generatePassword(emp);
		empcred.showCredentials(emp);
		sc.close();
	}
    
}
